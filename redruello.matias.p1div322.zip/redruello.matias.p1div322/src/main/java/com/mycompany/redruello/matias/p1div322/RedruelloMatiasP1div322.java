/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.redruello.matias.p1div322;

import Model.CentroDeEntrenamiento;
import Model.RedesNeuronales;
import Model.TipoDato;

/**
 *
 * @author PC
 */
public class RedruelloMatiasP1div322 {

    public static void main(String[] args) {
        //Pruebas Agregar modelo al sistema
        CentroDeEntrenamiento c1 = new CentroDeEntrenamiento();
        
        RedesNeuronales r1 =new RedesNeuronales("ClasificadorImagenes", "Lab1", TipoDato.DATOS_NUMERICOS);
        RedesNeuronales r2 = new RedesNeuronales("DeteccionDeRostros", "Lab2", TipoDato.DATOS_NUMERICOS);
        c1.agrgarModelo(r1);
        //c1.agrgarModelo(r1);
        
        c1.agrgarModelo(r2);
        //Mostrar modelos
        c1.mostrarModelo();
        
        //
        
    }
}
