/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */
package com.mycompany.redruello.matias.p1div322;

import Exceptions.ModeloRepetidoException;
import Model.AlgoritmosGeneticos;
import Model.ArbolesDeDecision;
import Model.CentroDeEntrenamiento;
import Model.CriterioDeDivision;
import Model.Modelos;
import Model.RedesNeuronales;
import Model.TipoEntrenamiento;
import java.util.List;

/**
 *
 * @author PC
 */
public class RedruelloMatiasP1div322 {

    /* public static void main(String[] args) {
        try {
            //Pruebas Agregar modelo al sistema
            CentroDeEntrenamiento c1 = new CentroDeEntrenamiento();

            RedesNeuronales r1 = new RedesNeuronales("Clasificador Imagenes", "Lab1", TipoEntrenamiento.DATOS_NUMERICOS, 5);
            RedesNeuronales r2 = new RedesNeuronales("Deteccion De Rostros", "Lab2", TipoEntrenamiento.DATOS_NUMERICOS, 8);
            AlgoritmosGeneticos a1 = new AlgoritmosGeneticos("Algo-Gen 1", "Lab3", 5, TipoEntrenamiento.DATOS_NUMERICOS);
            ArbolesDeDecision a2 = new ArbolesDeDecision("Arbol 1", "Lab4", TipoEntrenamiento.DATOS_TEXTUALES, CriterioDeDivision.GINI);
            c1.agrgarModelo(r1);
            //c1.agrgarModelo(r1);
            c1.agrgarModelo(a2);
            c1.agrgarModelo(a1);
            c1.agrgarModelo(r2);
            //Mostrar modelos
            c1.mostrarModelo();

            //Entrenable 
            c1.entrenarModelo();

            //Filtrar por tipoDato
            System.out.println("FILTRADO: ");

            List<Modelos> listaFiltrada = c1.filtrarPorTipoDatos(TipoEntrenamiento.DATOS_NUMERICOS);

            for (Modelos m : listaFiltrada) {
                System.out.println(m);
            }
        } catch (NullPointerException ex) {
            System.out.println(ex.getMessage());
        } catch (ModeloRepetidoException ex) {
            System.out.println(ex.getMessage());
        }

    }*/
    public static void main(String[] args) {
        try {
            CentroDeEntrenamiento c1 = new CentroDeEntrenamiento();
            precargarModelos(c1);

            System.out.println("Modelos cargados:");
            c1.mostrarModelo();

            System.out.println("\nEntrenando modelos...");
            c1.entrenarModelo();

            System.out.println("\nFILTRADO: ");
            List<Modelos> listaFiltrada = c1.filtrarPorTipoDatos(TipoEntrenamiento.DATOS_NUMERICOS);
            for (Modelos m : listaFiltrada) {
                System.out.println(m);
            }

        } catch (NullPointerException | ModeloRepetidoException ex) {
            System.out.println(ex.getMessage());
        }
    }

    public static void precargarModelos(CentroDeEntrenamiento c1){
        RedesNeuronales r1 = new RedesNeuronales("Clasificador Imagenes", "Lab1", TipoEntrenamiento.DATOS_NUMERICOS, 5);
        RedesNeuronales r2 = new RedesNeuronales("Deteccion De Rostros", "Lab2", TipoEntrenamiento.DATOS_NUMERICOS, 8);
        AlgoritmosGeneticos a1 = new AlgoritmosGeneticos("Algo-Gen 1", "Lab3", 5, TipoEntrenamiento.DATOS_NUMERICOS);
        ArbolesDeDecision a2 = new ArbolesDeDecision("Arbol 1", "Lab4", TipoEntrenamiento.DATOS_TEXTUALES, CriterioDeDivision.GINI);

        c1.agrgarModelo(r1);
        c1.agrgarModelo(r1);
        c1.agrgarModelo(a1);
        c1.agrgarModelo(a2);
    }
}
