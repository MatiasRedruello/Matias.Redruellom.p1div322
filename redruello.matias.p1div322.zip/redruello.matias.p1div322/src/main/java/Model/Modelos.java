package Model;

import java.util.Objects;

public abstract class Modelos {

    private String nombre;
    private String laboratorio;
    private TipoEntrenamiento tipo;

    public Modelos(String nombre, String laboratorio, TipoEntrenamiento tipo) {
        this.nombre = nombre;
        this.laboratorio = laboratorio;
        this.tipo = tipo;
    }

    public String getNombre() {
        return this.nombre;
    }

    public boolean esTipoEntrenamiento(TipoEntrenamiento tipo) {
        return this.tipo == tipo;
    }

    @Override
    public String toString() {
        return "nombre: " + nombre + ", laboratorio: " + laboratorio + ", tipo: " + tipo + ", ";
    }

    @Override
    public int hashCode() {
        return Objects.hash(this.nombre, this.laboratorio);
    }

    @Override
    public boolean equals(Object o) {
        if (o == null || !(o instanceof Modelos)) {
            return false;
        }
        Modelos otro = (Modelos) o;

        return this.nombre.equals(otro.nombre) && this.laboratorio.equals(otro.laboratorio);
    }

}
