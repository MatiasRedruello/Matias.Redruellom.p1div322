
package Model;


public enum TipoEntrenamiento {
    DATOS_NUMERICOS,
    DATOS_TEXTUALES
}
