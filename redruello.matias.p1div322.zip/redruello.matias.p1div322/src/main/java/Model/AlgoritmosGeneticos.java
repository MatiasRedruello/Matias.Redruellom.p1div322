package Model;


public class AlgoritmosGeneticos extends Modelos {

    private double tasaDeMutacion;

    public AlgoritmosGeneticos(String nombre, String laboratorio, double tasa, TipoEntrenamiento tipo) {
        super(nombre, laboratorio, tipo);
        this.tasaDeMutacion = tasa;

    }

    @Override
    public String toString() {
        return super.toString() + "tasaDeMutacion: " + tasaDeMutacion;
    }

}
