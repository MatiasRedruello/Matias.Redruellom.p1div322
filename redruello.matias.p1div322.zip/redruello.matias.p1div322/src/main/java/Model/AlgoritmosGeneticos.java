/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Model;

/**
 *
 * @author PC
 */
public class AlgoritmosGeneticos extends Modelos{
    private String nombre;
    private String laboratorio;
    private double tasaDeMutacion;
    private TipoDato tipo;
    
    public AlgoritmosGeneticos(String nombre,String laboratorio,double tasa, TipoDato tipo){
        this.nombre = nombre;
        this.laboratorio = laboratorio;
        this.tasaDeMutacion = tasa;
        this.tipo = tipo;
        
    }

    @Override
    public String toString() {
        return "AlgoritmosGeneticos{" + "nombre=" + nombre + 
                ", laboratorio=" + laboratorio + ", tasaDeMutacion=" + 
                tasaDeMutacion + ", tipo=" + tipo + '}';
    }

    @Override
    public boolean equals(Object o) {
        if (o == null || !(o instanceof AlgoritmosGeneticos)) {
            return false;
        }
        AlgoritmosGeneticos other = (AlgoritmosGeneticos) o;
        return this.nombre.equals(other.nombre) && this.laboratorio.equals(other.laboratorio);

    }    
    
    
}
