package Model;

import Exceptions.ModeloRepetidoException;
import java.util.ArrayList;
import java.util.List;

public class CentroDeEntrenamiento {

    private List<Modelos> modelo;

    public CentroDeEntrenamiento() {

        this.modelo = new ArrayList<>();
    }

    public void agrgarModelo(Modelos modelo) {
        for (Modelos m:this.modelo) {
           if(m.equals(modelo)){
               throw new ModeloRepetidoException();
           }
             
        }
        this.modelo.add(modelo);
    }

    public void mostrarModelo() {
        for (Modelos m : modelo) {
            System.out.println(m.toString());
        }
    }

    public void entrenarModelo() {
        
    }

    public String filtrarPorTipoDatos(TipoDato tipo) {
        return "fsdfs";
    }

}
