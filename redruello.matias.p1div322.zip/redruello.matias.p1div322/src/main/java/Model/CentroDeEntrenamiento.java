package Model;

import Exceptions.ModeloRepetidoException;
import Interfaces.Entrenable;
import java.util.ArrayList;
import java.util.List;

public class CentroDeEntrenamiento {

    private List<Modelos> modelos = new ArrayList<>();

    //constructor por defecto
    public void agrgarModelo(Modelos m) {
        validarModelos(m);
        this.modelos.add(m);
    }

    public void mostrarModelo() {
        if (modelos.isEmpty()) {
            System.out.println("No hay modelos de entrenamiento");
        } else {
            System.out.println("Modelos de entrenamiento: ");
            for (Modelos m : this.modelos) {

                System.out.println(m);
            }
        }

    }

    public void entrenarModelo() {
        System.out.println("Entrenar Modelos: ");
        for (Modelos m : this.modelos) {
            if (m instanceof Entrenable e) {
                System.out.println(e.entrenar());

            } else {
                System.out.println(m.getNombre() + "  No requiere entrenamiento manual");
            }
        }
    }

    public List<Modelos> filtrarPorTipoDatos(TipoEntrenamiento tipo) {
        List<Modelos> toReturn = new ArrayList<>();
        for (Modelos m : this.modelos) {
            if (m.esTipoEntrenamiento(tipo)) {
                toReturn.add(m);
            }
        }
        return toReturn;
    }

    private void validarModelos(Modelos m) {
        if (m == null) {
            throw new NullPointerException("Modelo nulo");
        }
        if (modelos.contains(m)) {
            throw new ModeloRepetidoException(m.getNombre() + " Modelo Repetido");
        }

    }

}
