package Model;

import Interfaces.Entrenable;
import java.util.Objects;

public class ArbolesDeDecision extends Modelos implements Entrenable {

    private CriterioDeDivision criterio;

    public ArbolesDeDecision(String nombre, String laboratorio, TipoEntrenamiento tipo, CriterioDeDivision criterio) {
        super(nombre, laboratorio, tipo);
        this.criterio = criterio;

    }

    @Override
    public String entrenar() {
        return "%s  entrenando...".formatted(getNombre());
    }

    @Override
    public String toString() {
        return super.toString() + "criterio: " + criterio;
    }

}
