/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Model;

import Interfaces.Entrenable;
import java.util.Objects;

/**
 *
 * @author PC
 */
public class ArbolesDeDecision extends Modelos implements Entrenable {

    private String nombre;
    private String laboratorio;
    private TipoDato tipo;
    private CriterioDeDivision criterio;

    public ArbolesDeDecision(String nombre, String laboratorio, TipoDato tipo, CriterioDeDivision criterio) {
        this.nombre = nombre;
        this.laboratorio = laboratorio;
        this.tipo = tipo;
        this.criterio = criterio;

    }

    public String entrenar() {
        return  "soy:  %s y estoy entrenando".formatted(nombre);
    }

    @Override
    public String toString() {
        return "ArbolesDeDecision{" + "nombre=" + nombre 
                + ", laboratorio=" + laboratorio + ", tipo=" + tipo 
                + ", criterio=" + criterio + '}';
    }



    @Override
    public boolean equals(Object o) {
        if (o == null || !(o instanceof ArbolesDeDecision))
            return false;
        ArbolesDeDecision other = (ArbolesDeDecision) o;
        return this.nombre.equals(other.nombre)  && this.laboratorio.equals(other.laboratorio);
        
    }
    
}
