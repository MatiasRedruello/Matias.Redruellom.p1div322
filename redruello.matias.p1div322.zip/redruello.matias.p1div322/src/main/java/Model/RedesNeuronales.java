/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Model;

import Interfaces.Entrenable;

/**
 *
 * @author PC
 */
public class RedesNeuronales extends Modelos implements Entrenable {

    private String nombre;
    private String laboratorio;
    private TipoDato tipo;

    public RedesNeuronales(String nombre, String laboratorio, TipoDato tipo) {
        this.nombre = nombre;
        this.laboratorio = laboratorio;
        this.tipo = tipo;

    }

    public String entrenar() {
        return "soy:  %s y estoy entrenando".formatted(nombre);
    }

    @Override
    public String toString() {
        return "RedesNeuronales{" + "nombre=" + nombre
                + ", laboratorio=" + laboratorio
                + ", tipo=" + tipo + '}';
    }

    @Override
    public boolean equals(Object o) {
        if (o == null || !(o instanceof RedesNeuronales)) {
            return false;
        }
        RedesNeuronales other = (RedesNeuronales) o;
        return this.nombre.equals(other.nombre) && this.laboratorio.equals(other.laboratorio);

    }
}
