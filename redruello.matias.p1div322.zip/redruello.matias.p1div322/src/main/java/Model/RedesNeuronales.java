package Model;

import Interfaces.Entrenable;

public class RedesNeuronales extends Modelos implements Entrenable {

    private int capas;

    public RedesNeuronales(String nombre, String laboratorio, TipoEntrenamiento tipo, int capas) {
        super(nombre, laboratorio, tipo);
        this.capas = capas;
    }
    
    @Override
    public String entrenar() {
        return "%s entrenando...".formatted(getNombre());
    }

    @Override
    public String toString() {
        return super.toString() + "Capas: " + this.capas;
    }
}
