/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Exceptions;

/**
 *
 * @author PC
 */
public class ModeloRepetidoException extends RuntimeException {

    private static final String MENSAJE = "Modelo repetido";

    public ModeloRepetidoException() {
        this(MENSAJE);

    }

    public ModeloRepetidoException(String msg) {
        super(msg);
    }
}
