/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Model;

import java.time.LocalDate;
import java.util.Date;

public abstract class Hallazgos {

    private static final int ID_INICIAL = 50000;
    private static int nextId = ID_INICIAL;
    private static int MIN = 1;
    private static int MAX = 10;

    private String nombre;
    private LocalDate fecha;
    private int conservasion;
    private int id;

    public Hallazgos(String nombre, LocalDate fecha, int conservasion) {

        validarConservacion(conservasion);
        this.id = getNextId();
        this.nombre = nombre;
        this.fecha = fecha;
        this.conservasion = conservasion;

    }

    public static int getNextId() {
        return nextId++;
    }

    public int getMin() {
        return MIN;
    }

    public int getMax() {
        return MIN;
    }

    private void validarConservacion(int c) {
        if (c < MIN || c > MAX) {
            throw new IllegalArgumentException("Fuera de rango");
        }
    }

    public String getNombre() {
        return nombre;
    }

    public boolean esEpocaHistorica() {
        return true;
    }

    @Override
    public String toString() {
        return "nombre: " + nombre + ", fecha: " + fecha + ", conservasion: " + conservasion + ", id=" + id + ", ";
    }

    @Override
    public boolean equals(Object o) {
        if (o == null || !(o instanceof Hallazgos )) {
            return false;
        }
        Hallazgos otro = (Hallazgos) o;

        return this.id == otro.id;
    }

}
