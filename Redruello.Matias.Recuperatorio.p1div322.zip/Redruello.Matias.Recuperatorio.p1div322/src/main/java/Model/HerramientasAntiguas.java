/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Model;

import Interfaces.Analizable;
import java.time.LocalDate;
import java.util.Date;

/**
 *
 * @author PC
 */
public class HerramientasAntiguas extends Hallazgos implements Analizable {
    
    private String material;
    private String uso;

    public HerramientasAntiguas( String nombre, LocalDate fecha, int conservasion,String material, String uso) {
        super(nombre, fecha, conservasion);
        this.material = material;
        this.uso = uso;
    }

    @Override
    public String analizar() {
        return "Analizando...";
    }

    @Override
    public String toString() {
        return super.toString()+ "material: " + material + ", uso: " + uso ;
    }
    
    
    
}
