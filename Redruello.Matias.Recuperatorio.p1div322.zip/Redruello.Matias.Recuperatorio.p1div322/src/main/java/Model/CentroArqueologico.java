package Model;

import Exceptions.HallazgoRepetidoException;
import Interfaces.Analizable;
import Interfaces.Restaurable;
import java.util.ArrayList;
import java.util.List;

public class CentroArqueologico {

    private List<Hallazgos> hallazgos = new ArrayList<>();

    public void registrarNuevoHallazgo(Hallazgos h) {
        validarHallazgos(h);
        hallazgos.add(h);
    }

    public void listarHallazgo() {
        if (hallazgos.isEmpty()) {
            System.out.println("No hay hallazgos arqueologicos");
        } else {
            System.out.println("Allazgos: ");
            for (Hallazgos h : this.hallazgos) {

                System.out.println(h);
            }
        }
    }

    public void ejecutarAnalisisLabo() {
        System.out.println("Analizar: ");
        for (Hallazgos h : this.hallazgos) {
            if (h instanceof Analizable a) {
                System.out.println(a.analizar());

            }
        }
    }

    public void realizarResturacion() {
        System.out.println("Restaurar: ");
        for (Hallazgos h : this.hallazgos) {
            if (h instanceof Restaurable r) {
                System.out.println(r.restaurar());

            }
        }
    }

    public List<Hallazgos> filtrarPorEpocaHistorica(EpocaHistorica epoca) {
        List<Hallazgos> toReturn = new ArrayList<>();
        for (Hallazgos h : this.hallazgos) {
            if (h instanceof Ruinas r ) {
                
                if (r.esEpocaHistorica(epoca)) {
                    toReturn.add(r);
                }
            }
        }
        return toReturn;

    }

    public void mostarHallazgoEstadoConservacion(int min,int max) {
        System.out.println("Hallazgo por estado de conservacion");
        for (Hallazgos h : this.hallazgos) {
            if(h.getMin() > min && h.getMax() < max )
                System.out.println(h.getNombre());
        }
    }

    private void validarHallazgos(Hallazgos h) {
        if (h == null) {
            throw new NullPointerException("Modelo nulo");
        }
        if (this.hallazgos.contains(h)) {
            throw new HallazgoRepetidoException(h.getNombre() + " Modelo Repetido");
        }

    }

}
