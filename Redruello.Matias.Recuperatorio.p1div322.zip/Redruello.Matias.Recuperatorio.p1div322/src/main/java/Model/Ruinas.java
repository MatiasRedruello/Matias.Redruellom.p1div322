/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Model;

import Interfaces.Restaurable;
import java.time.LocalDate;
import java.util.Date;

/**
 *
 * @author PC
 */
public class Ruinas extends Hallazgos implements Restaurable {

    private TipoEdificacion tipo;
    private EpocaHistorica epoca;

    public Ruinas(String nombre, LocalDate fecha, int conservasion, TipoEdificacion tipo, EpocaHistorica epoca) {
        super(nombre, fecha, conservasion);
        this.tipo = tipo;
        this.epoca = epoca;
    }

    public boolean esEpocaHistorica(EpocaHistorica epoca) {
        return this.epoca == epoca;
    }

    @Override
    public String restaurar() {
        return "Restaurando...";
    }

    @Override
    public String toString() {
        return super.toString() + "Tipo de Edificacion" + tipo + "Epoca" + epoca;
    }
    
    

}
