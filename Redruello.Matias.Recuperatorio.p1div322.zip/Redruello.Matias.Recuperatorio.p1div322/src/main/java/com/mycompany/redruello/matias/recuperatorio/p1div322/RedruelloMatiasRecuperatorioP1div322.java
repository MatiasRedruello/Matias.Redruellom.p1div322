/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */
package com.mycompany.redruello.matias.recuperatorio.p1div322;

import Exceptions.HallazgoRepetidoException;
import Model.CentroArqueologico;
import Model.EpocaHistorica;
import Model.HerramientasAntiguas;
import Model.RestosFosiles;
import Model.Ruinas;

import java.time.LocalDate;
import java.time.Month;

/**
 *
 * @author PC
 */
public class RedruelloMatiasRecuperatorioP1div322 {

    public static void main(String[] args) {
                // no llegue armar bien el mail pero apuesto un asadito que esto anda
        try {
            //Pruebas Agregar modelo al sistema
            CentroArqueologico ca1 = new CentroArqueologico();

            RestosFosiles re1 = new RestosFosiles()
            Ruinas ru2 = new Ruinas();
            HerramientasAntiguas h1 = new HerramientasAntiguas();

            ca1.registrarNuevoHallazgo(ru2);
            ca1.registrarNuevoHallazgo(h1);
            ca1.registrarNuevoHallazgo(h1);
            //Mostrar modelos
            

            //listarHallazgo 
            ca1.listarHallazgo();

            //ejecutarAnalisisLabo
            ca1.ejecutarAnalisisLabo();
            
            //realizarResturacion
            ca1.realizarResturacion();
            
            //filtrarPorEpocaHistorica
            ca1.filtrarPorEpocaHistorica(EpocaHistorica.COLONIAL);
            //mostarHallazgoEstadoConservacion
            ca1.ejecutarAnalisisLabo();
        
    
    

            
        } catch (NullPointerException ex) {
            System.out.println(ex.getMessage());
        } catch (IllegalArgumentException ex) {
            System.out.println(ex.getMessage());

        } catch (HallazgoRepetidoException ex) {
            System.out.println(ex.getMessage());
        } catch (Exception ex){
            System.out.println(ex.getMessage());
        }

    }
}
