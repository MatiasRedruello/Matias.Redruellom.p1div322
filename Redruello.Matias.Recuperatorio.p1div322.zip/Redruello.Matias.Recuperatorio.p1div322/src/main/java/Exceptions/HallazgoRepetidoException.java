/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Exception.java to edit this template
 */
package Exceptions;

/**
 *
 * @author PC
 */
public class HallazgoRepetidoException extends RuntimeException{

    private static final String MENSAJE="Hallazgo repetido";
    
    public HallazgoRepetidoException() {
        this(MENSAJE);
    }


    public HallazgoRepetidoException(String msg) {
        super(msg);
    }
}
